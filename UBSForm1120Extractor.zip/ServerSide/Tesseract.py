import pytesseract as pytesseract


class Tesseract:
    def __init__(self, cropped):
        self.cropped = cropped

    def tesseract(self):
        cropped = self.cropped
        result = pytesseract.image_to_string(cropped, lang="eng")

        return result
